package files;

public class Payload {
	public static String getPayload(String fname,String lname) {
		String payload="{\r\n" + 
				"    \"id\": \"950\",\r\n" + 
				"    \"createdAt\": \"2019-09-27T08:37:03.228Z\"\r\n" + 
				"}";
		return payload;
	}

}
