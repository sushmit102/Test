package tra;

/*import java.io.IOException;

import org.testng.annotations.Test;

public class Home extends Base{
	
	@Test
	public void launchbrowser() throws IOException{
		Myaccount();
	}

	

	
		
	}*/
	
	


